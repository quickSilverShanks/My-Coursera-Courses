# Hiring

Getting new people to join Blendle is a **high effort, high impact** thing to do. The reward is huge, when you see the people you hired adding value to the company. Imagine not hiring that person: that new idea, design, piece of code, algorithm or audio show would not have been there. Your hire could be key to the succes of Blendle: that's a lot of impact. The other side of the same coin is that it's high effort too. These 4 pointers will help you get started. 

- **Personnel planning**
    
    Planning the number and type of people you need in the future is hard but also crucial. Hiring people takes time (~3 months), so looking ahead is important for making your projects succeed. Without the right (number of) people, it's hard to build a cool product.
    
    When making plans for **the coming and next quarter:**
    
    1. **Determine what work needs to be done, looking 3-6 months ahead, and decide if we have enough resources to do so.** 
        
        Our basic premise is that we work with the team we have and we hire reactively. But ask yourself a few questions. Do you have the right number and type of people? What kind of skills, expertise, experience do you need in what amount? What can we fix internally? What can we teach the people who are at Blendle? What can we just try with advice from outside? Is your ask temporary or permanent? How is the current workload? Can we afford to ship less quickly? 
        
    2. **Keep teams small.** More then 4-6 people creates more overhead (mainly communication like e-mail/slack and interactions in general) and doesn't necessarily mean that the team performs better. Jeff Bezos calls it the 2 pizza rule (you should be able to feed your team with 2 pizzas) and Ringelmann discovered 'social loafing' in 1914. People unintentionally slack when the group gets too big. Read more about this here:
        
        [The psychological theory that explains why you're better off working solo](https://qz.com/848267/the-ringelmann-effect-productivity-increases-when-youre-working-solo-rather-than-on-a-team/)
        
        [What is the optimal group size for decision-making? - Sheila Margolis](https://sheilamargolis.com/2011/01/24/what-is-the-optimal-group-size-for-decision-making/)
        
    3. **Keep budget in mind.** You should focus on getting the best team for the work you need done, but budget does play a role in this. People are our most important and most expensive resource. Hiring, therefore, is an expensive solution to a problem. 
    4. **Plan.** Discuss this step with your lead and HR.
        
        To be able to plan you need these variables: Team, Role, Profile and role description, Hitlist, Priority, Scarceness (1-5), Years of relevant experience, Salary range, Planning. 
        
         Here's an example of a template we've used in the past to plan our hiring Blendle-wide:
        
        [Google Sheets - create and edit spreadsheets online, for free.](https://docs.google.com/spreadsheets/d/1X9C2vGjxwdD2RSXcObW6A9rgd5XaD-zoFL1OIw5y5kQ/edit#gid=981401373)
        
- **Determine role: intake**
    
    [Opening up a new job](Hiring%208c7049f20ed74df982f8e05bc3dca30b/Opening%20up%20a%20new%20job%20f225914896844170b1cc5379f73e580f.md)
    
    UPDATE 2019: Please also check ↖︎
    
    Alright, so you came to the conclusion you need to hire someone. The next step is to pin down what you are (and aren't) exactly looking for in a candidate. This step is crucial. Rush this and you'll find yourself wobbling further down the road. 
    
    *Ask for help from recruitment/HR with this. They can help you out.*
    
    This set of questions should help you define your perfect candidate.
    
    - What team will the new person be joining? What is the goal of that team and how does that new person's job fit in there?
    - What problems are we aiming to solve by hiring this person? What would it look like when the problem is solved?
    - What impact do we expect this person to make in his/her - let's say - first 6 months?
    - What does good performance and success look like for this person? What do you expect from him/her?
    - What challenges or downsides does this role have?
    - What would you call the role? Is it an existing role (if yes: think if you can use someone as a blueprint, if no: make sure to check if our job title matches with other companies).
    - How much experience do you think this person needs? What kind and type of experience? In what kind and type of environments? Do you expect this person to be plug and play or is there room for learning and growing?
    - What could someone's career path look like at Blendle? What do we have to offer there?
    - Do you expect this person to lead a team or guild in a way?
    - What would a average week look like for this person?
    - What are examples of projects that were there the last quarter which could have been done by the new hire? What projects or topics are coming up?
    - What kind of skills, knowledge, expertise or experience does this person need? Make a distinction between must-haves and nice-to-haves. Be specific.
    - What kind of skills are lacking in the current team which this new person should bring?
    - Selling points: why would someone quit his job for this role? Think about the team, the role and Blendle.
    
    Share this with the hiring team, so everybody is on the same page on what we are looking for.
    
    **When pinning down the profile, keep [the Matrix™](https://docs.google.com/spreadsheets/d/1HO4cEH0dguBywUzjT3FMUSGiJbgGjOQDdaILl0BaJME/edit#gid=1890661785) and Work, Drive and Fit in mind. That's also what your hiring team is going to rate the candidates on, so it's good to know what they have to be rating.** 
    
    If it's a new role, it can be hard to pin these questions down. You can use this set of questions to ask experts in the field to help you pin down the profile as described in the section '[Getting people in'](https://www.notion.so/beae540c6eb54f87b43bb2123d50f23e?pvs=21) section 3: Sourcing:
    
    > Source to pin down your profile. New roles can be hard to pin down in a few bullet points. Since we can only hire (or turn down) someone if we know exactly what we are looking for, sourcing can be a good addition. Make a list of 20 people who match your profile so far on paper, ask your top 5 if they would like to have a cup of coffee with you. Use those conversations to finish your profile.
    > 
- **Finish job description & get started**
    
    Go to [admin.homerun.co](http://admin.homerun.co) and log in with your google account from Blendle.
    
    1. Ask HR to duplicate a template for you and make you hiring manager or reuse an existing job description and go from there. 
    2. Go to edit:
        
        ![Hiring%208c7049f20ed74df982f8e05bc3dca30b/Schermafbeelding2018-07-10om13.11.25.png](Hiring%208c7049f20ed74df982f8e05bc3dca30b/Schermafbeelding2018-07-10om13.11.25.png)
        
    3. Adjust the job description to your liking:
        - The first section is about the team, what they do and the reason why we are hiring.
        - The second section consists of the 4-5 reasons we chose to work at Blendle. You can alter them, but you can keep those the same.
        - The third section is our wishlist: alter these to get the most important stuff from your intake (above) across.
        - The last step is altering the Application form (click 'Application form' next to 'Job post').
            
            ![Hiring%208c7049f20ed74df982f8e05bc3dca30b/Schermafbeelding2018-07-10om13.15.50.png](Hiring%208c7049f20ed74df982f8e05bc3dca30b/Schermafbeelding2018-07-10om13.15.50.png)
            
            The section 'Questions' is most important for now. Make sure to come up with a few good job-related questions based on your intake. For example for Android dev: 'Tell us about the app you have in the store :)'. Be creative: a good question tells you a lot more than a well-designed resume.
            
        - Click save and publish (on the right) and add the right people to the hiring team so they get to see the applicants too.
- **Hiring process**
    
    [Hiring process](Hiring%208c7049f20ed74df982f8e05bc3dca30b/Hiring%20process%204f4f5d16c34f4688b744591883657c37.md)
    
    [Interviewing](Hiring%208c7049f20ed74df982f8e05bc3dca30b/Interviewing%2085070c8a34284bfd92d4dda389b414c4.md)
    
    The blueprint of the hiring process + responsibilities can be found here:
    
    [https://www.notion.so/blendle/Hiring-process-c19f8f3d05034b42b2bb42e330b8a934](https://www.notion.so/Hiring-process-c19f8f3d05034b42b2bb42e330b8a934?pvs=21)
    
- **Get new people up to speed**
    
    Give your new hires a smooth start. Here's how.
    
    - **Coordinate with HR** about starting date and the first day.
    - For the first month, **create a set of goals and expectations** which you share with your new hire in the first few days.
        
        **Check this page** for the structure, timeline and templates for goals/expectations.
        
        [Your 1st month ](Your%201st%20month%20c6f4af5517c84d4087e635587961fb0e.md)
        
    - **Confirm your hire**. The first month is the trial period. This is not an extended hiring process, but make sure to validate your hire from both sides. If there are any doubts, flag it with your lead or HR and consider building in more check-ins.

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).